// Ce fichier n'est plus utilisé
// L'enrichissement se fait maintenant directement dans hooks/useWineEnrichment.ts
// sans aucune base de données externe, uniquement avec l'OCR Google Vision

export function enrichWineData(ocrData: any) {
  return ocrData;
} 