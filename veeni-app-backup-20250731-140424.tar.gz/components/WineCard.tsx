import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import {
    Dimensions,
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';

const { width } = Dimensions.get('window');

// Types sécurisés pour éviter les objets complexes
export interface WineCardProps {
  wine: {
    id: string;
    name: string;
    vintage: number | null;
    color: 'red' | 'white' | 'rose' | 'sparkling';
    domaine: string;
    region: string;
    country: string;
    grapes: string[];
    imageUri: string | null;
    stock: number;
    origin: 'cellar' | 'wishlist';
    note: number | null;
    personalComment: string | null;
    favorite?: boolean;
  };
  showStockButtons?: boolean;
  showActions?: boolean;
  onPress?: () => void;
  onAddBottle?: () => void;
  onRemoveBottle?: () => void;
  onEdit?: () => void;
  onToggleFavorite?: () => void;
  footer?: React.ReactNode;
  isSharedCave?: boolean;
  sharedWith?: string;
  readOnly?: boolean;
  // Nouvelles props pour les informations sociales
  friendsWithWine?: Array<{
    id: string;
    firstName: string;
    avatar?: string;
  }>;
}

export const WineCard: React.FC<WineCardProps> = ({
  wine,
  showStockButtons = true,
  showActions = true,
  onPress,
  onAddBottle,
  onRemoveBottle,
  onEdit,
  onToggleFavorite,
  footer,
  isSharedCave = false,
  sharedWith,
  readOnly = false,
  friendsWithWine = [],
}) => {
  // Fonction de nettoyage pour s'assurer que tous les champs sont des primitifs
  const safeWine = {
    id: String(wine.id || ''),
    name: String(wine.name || 'Nom inconnu'),
    vintage: wine.vintage || null,
    color: wine.color || 'red',
    domaine: String(wine.domaine || 'Domaine inconnu'),
    region: String(wine.region || ''),
    country: String(wine.country || ''),
    grapes: Array.isArray(wine.grapes) ? wine.grapes.map(String) : [],
    imageUri: wine.imageUri || null,
    stock: Number(wine.stock || 0),
    origin: wine.origin || 'cellar',
    note: wine.note || null,
    personalComment: wine.personalComment || null,
    favorite: wine.favorite || false,
  };

  const getWineTypeColor = (color: string) => {
    switch (color) {
      case 'red': return '#FF4F8B';
      case 'white': return '#FFF8DC';
      case 'rose': return '#FFB6C1';
      case 'sparkling': return '#FFD700';
      default: return '#FF4F8B';
    }
  };

  const getWineTypeIcon = (color: string) => {
    switch (color) {
      case 'red': return 'wine';
      case 'white': return 'wine-outline';
      case 'rose': return 'wine-outline';
      case 'sparkling': return 'sparkles';
      default: return 'wine';
    }
  };

  const truncateText = (text: string, maxLength: number) => {
    return text.length > maxLength ? `${text.substring(0, maxLength)}...` : text;
  };

  // Fonction pour obtenir le drapeau du pays
  const getCountryFlag = (country: string) => {
    const flagMap: Record<string, string> = {
      'France': '🇫🇷',
      'Italie': '🇮🇹',
      'Espagne': '🇪🇸',
      'Portugal': '🇵🇹',
      'Allemagne': '🇩🇪',
      'États-Unis': '🇺🇸',
      'Chili': '🇨🇱',
      'Argentine': '🇦🇷',
      'Australie': '🇦🇺',
      'Nouvelle-Zélande': '🇳🇿',
      'Afrique du Sud': '🇿🇦',
      'Canada': '🇨🇦',
      'Suisse': '🇨🇭',
      'Autriche': '🇦🇹',
      'Hongrie': '🇭🇺',
      'Grèce': '🇬🇷',
      'Croatie': '🇭🇷',
      'Slovénie': '🇸🇮',
      'Géorgie': '🇬🇪',
      'Liban': '🇱🇧',
      'Israël': '🇮🇱',
      'Maroc': '🇲🇦',
      'Tunisie': '🇹🇳',
      'Algérie': '🇩🇿',
    };
    return flagMap[country] || '🏳️';
  };

  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.8}
      disabled={readOnly}
    >
      {/* Layout principal en row */}
      <View style={styles.rowContainer}>
        {/* Image du vin à gauche */}
        <View style={styles.imageCol}>
          <View style={styles.imageWrapper}>
            {safeWine.imageUri ? (
              <Image
                source={{ uri: safeWine.imageUri }}
                style={styles.wineImage}
                resizeMode="cover"
              />
            ) : (
              <View style={[styles.placeholderImage, { backgroundColor: getWineTypeColor(safeWine.color) }]}> 
                <Ionicons name={getWineTypeIcon(safeWine.color)} size={32} color="#FFF" />
              </View>
            )}
            {/* Bouton favori en haut à droite de l'image */}
            {showActions && onToggleFavorite && (
              <TouchableOpacity
                style={styles.likeButton}
                onPress={onToggleFavorite}
                disabled={readOnly}
              >
                <Ionicons
                  name={safeWine.favorite ? 'heart' : 'heart-outline'}
                  size={20}
                  color={safeWine.favorite ? '#FF4F8B' : '#FFF'}
                />
              </TouchableOpacity>
            )}
          </View>
        </View>
        {/* Bloc infos à droite */}
        <View style={styles.infoCol}>
          {/* Section supérieure : nom */}
          <View style={styles.headerRow}>
            <Text style={styles.wineName} numberOfLines={2}>{truncateText(safeWine.name || 'Nom inconnu', 40)}</Text>
          </View>
          
          {/* Section centrale : informations du vin */}
          <View style={styles.wineInfoSection}>
            {/* Millésime */}
            {safeWine.vintage && (
              <Text style={styles.vintageText}>{String(safeWine.vintage)}</Text>
            )}
            
            {/* Domaine/Producteur */}
            {safeWine.domaine && safeWine.domaine !== 'Domaine inconnu' && (
              <Text style={styles.domaine} numberOfLines={1}>{truncateText(safeWine.domaine, 35)}</Text>
            )}
            
            {/* Type de vin avec icône */}
            <View style={styles.wineTypeRow}>
              <Ionicons 
                name={getWineTypeIcon(safeWine.color)} 
                size={14} 
                color={getWineTypeColor(safeWine.color)} 
              />
              <Text style={styles.wineTypeText}>
                {safeWine.color === 'red' ? 'Rouge' : 
                 safeWine.color === 'white' ? 'Blanc' : 
                 safeWine.color === 'rose' ? 'Rosé' : 'Effervescent'}
              </Text>
            </View>
            
            {/* Région + Pays avec drapeau */}
            {(safeWine.region || safeWine.country) && (
              <View style={styles.regionRow}>
                <Text style={styles.region} numberOfLines={1}>
                  {safeWine.region && safeWine.country ? 
                    `${safeWine.region}, ${safeWine.country}` : 
                    safeWine.region || safeWine.country}
                </Text>
                {safeWine.country && (
                  <Text style={styles.countryFlag}>
                    {getCountryFlag(safeWine.country)}
                  </Text>
                )}
              </View>
            )}
            
            {/* Cépages */}
            {safeWine.grapes.length > 0 && (
              <Text style={styles.grapes} numberOfLines={1}>
                {safeWine.grapes.slice(0, 3).join(', ')}
                {safeWine.grapes.length > 3 && '...'}
              </Text>
            )}
            
            {/* Information sociale - Amis qui ont ce vin */}
            {friendsWithWine.length > 0 && (
              <View style={styles.socialRow}>
                <Ionicons name="people" size={12} color="#F6A07A" />
                <Text style={styles.socialText}>
                  Aussi chez {friendsWithWine.slice(0, 2).map(f => f.firstName).join(', ')}
                  {friendsWithWine.length > 2 && ` +${friendsWithWine.length - 2}`}
                </Text>
              </View>
            )}
            
            {/* Note personnelle */}
            {safeWine.note && safeWine.note > 0 && (
              <View style={styles.ratingContainer}>
                <Ionicons name="star" size={14} color="#FFD700" />
                <Text style={styles.rating}>{String(safeWine.note)}/5</Text>
              </View>
            )}
          </View>
          
          {/* Section inférieure : actions et footer */}
          <View style={styles.bottomSection}>
            {/* Boutons stock (seulement sur Ma cave) */}
            {showStockButtons && !readOnly && (
              <View style={styles.stockRow}>
                <TouchableOpacity
                  style={styles.stockButton}
                  onPress={onRemoveBottle}
                  disabled={safeWine.stock <= 0}
                >
                  <Ionicons
                    name="remove"
                    size={20}
                    color={safeWine.stock > 0 ? '#FFFFFF' : '#666'}
                  />
                </TouchableOpacity>
                <Text style={styles.stockText}>{String(safeWine.stock)}</Text>
                <TouchableOpacity
                  style={styles.stockButton}
                  onPress={onAddBottle}
                >
                  <Ionicons
                    name="add"
                    size={20}
                    color="#FFFFFF"
                  />
                </TouchableOpacity>
              </View>
            )}
            {/* Footer personnalisé */}
            {footer && (
              <View style={styles.footer}>{footer}</View>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#2A2A2A',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  imageContainer: {
    position: 'relative',
    width: '100%',
    height: 120,
  },
  wineImage: {
    width: '100%',
    height: '100%',
  },
  placeholderImage: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sharedBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(246, 160, 122, 0.9)',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
  },
  sharedText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '600',
    marginLeft: 4,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  nameContainer: {
    flex: 1,
    marginRight: 8,
  },
  wineName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 20,
  },
  vintage: {
    color: '#F6A07A',
    fontSize: 14,
    fontWeight: '500',
    marginTop: 2,
  },
  wineTypeBadge: {
    borderRadius: 12,
    padding: 4,
  },
  domaine: {
    color: '#CCC',
    fontSize: 12,
    marginBottom: 2,
  },
  region: {
    color: '#999',
    fontSize: 12,
    marginBottom: 4,
  },
  grapes: {
    color: '#999',
    fontSize: 12,
    fontStyle: 'italic',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  rating: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  actionButton: {
    padding: 12,
    minWidth: 44,
    minHeight: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stockText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginHorizontal: 20,
    minWidth: 30,
    textAlign: 'center',
  },
  footer: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  sharedInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  sharedInfoText: {
    color: '#F6A07A',
    fontSize: 12,
    marginLeft: 4,
  },
  rowContainer: {
    flexDirection: 'row',
    alignItems: 'stretch',
    width: '100%',
    height: 300,
    backgroundColor: '#2A2A2A',
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  imageCol: {
    width: 120,
    height: '100%',
    backgroundColor: '#222',
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageWrapper: {
    width: '100%',
    height: '100%',
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  wineImage: {
    width: '100%',
    height: '100%',
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
  },
  likeButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 16,
    padding: 8,
    zIndex: 2,
  },
  vintageText: {
    color: '#F6A07A',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  infoCol: {
    flex: 1,
    padding: 6,
    justifyContent: 'space-between',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 6,
  },
  wineName: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
    marginBottom: 4,
  },
  domaine: {
    color: '#CCC',
    fontSize: 16,
    marginBottom: 4,
  },
  region: {
    color: '#999',
    fontSize: 14,
    marginBottom: 2,
  },
  grapes: {
    color: '#999',
    fontSize: 14,
    fontStyle: 'italic',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  rating: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  stockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  stockText: {
    color: '#F6A07A',
    fontSize: 16,
    fontWeight: '600',
    minWidth: 20,
    textAlign: 'center',
    marginHorizontal: 6,
  },
  wineInfoSection: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  bottomSection: {
    justifyContent: 'flex-end',
  },
  // Nouveaux styles pour les informations ajoutées
  wineTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  wineTypeText: {
    color: '#999',
    fontSize: 14,
    marginLeft: 4,
    textTransform: 'capitalize',
  },
  regionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  countryFlag: {
    fontSize: 14,
    marginLeft: 4,
  },
  socialRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  socialText: {
    color: '#F6A07A',
    fontSize: 12,
    marginLeft: 4,
    fontStyle: 'italic',
  },
  stockButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2a2a2a',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#444444',
  },
}); 