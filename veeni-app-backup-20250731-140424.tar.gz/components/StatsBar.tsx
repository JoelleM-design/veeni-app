import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

interface StatsBarProps {
  values: { red: number; white: number; rose: number; sparkling: number; total: number };
  labels?: { red: string; white: string; rose: string; sparkling: string };
  totalLabel?: string;
  style?: any;
}

export const StatsBar: React.FC<StatsBarProps> = ({ values, labels, totalLabel = 'vins', style }) => {
  console.log('🔄 StatsBar: Re-rendu avec valeurs:', values); // Debug log
  const defaultLabels = {
    red: 'rouges',
    white: 'blancs',
    rose: 'rosés',
    sparkling: 'pétillants',
  };
  const l = labels || defaultLabels;
  return (
    <View style={[styles.statsOutlineBox, style]}>
      <View style={styles.statsRowOutline}>
        <View style={styles.statItemOutline}>
          <Text style={styles.statValueOutline}>{values.red}</Text>
          <Text style={styles.statLabelOutline}>{l.red}</Text>
        </View>
        <View style={styles.statItemOutline}>
          <Text style={styles.statValueOutline}>{values.white}</Text>
          <Text style={styles.statLabelOutline}>{l.white}</Text>
        </View>
        <View style={styles.statItemOutline}>
          <Text style={styles.statValueOutline}>{values.rose}</Text>
          <Text style={styles.statLabelOutline}>{l.rose}</Text>
        </View>
        <View style={styles.statItemOutline}>
          <Text style={styles.statValueOutline}>{values.sparkling}</Text>
          <Text style={styles.statLabelOutline}>{l.sparkling}</Text>
        </View>
      </View>
      <View style={styles.totalRowOutline}>
        <Text style={styles.totalValueOutline}>{values.total}</Text>
        <Text style={styles.totalLabelOutline}>{totalLabel}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  statsOutlineBox: {
    marginTop: 18,
    marginBottom: 0,
    marginHorizontal: 18,
    borderRadius: 28,
    borderWidth: 1.5,
    borderColor: '#444',
    backgroundColor: 'transparent',
    paddingVertical: 6,
    paddingHorizontal: 0,
    flexDirection: 'column',
    alignItems: 'stretch',
  },
  statsRowOutline: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    width: '100%',
    minHeight: 40,
  },
  statItemOutline: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingVertical: 2,
  },
  statValueOutline: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: 'System',
    marginBottom: 0,
  },
  statLabelOutline: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '400',
    fontFamily: 'System',
    marginBottom: 0,
    marginTop: 0,
    letterSpacing: 0.1,
  },
  totalRowOutline: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  totalValueOutline: {
    fontWeight: 'bold',
    fontSize: 18,
    fontFamily: 'System',
    color: '#FFF',
  },
  totalLabelOutline: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '400',
    fontFamily: 'System',
  },
}); 