import { useLocalSearchParams } from 'expo-router';
import WineDetailsScreen from '../../screens/WineDetailsScreen';

export default function WineDetailRoute() {
  const params = useLocalSearchParams();
  const id = params.id ? (typeof params.id === 'string' ? params.id : Array.isArray(params.id) ? params.id[0] : '') : '';
  const isFromOcr = params.isFromOcr === 'true';
  const tab = (params.tab as 'cellar' | 'wishlist' | 'tasted') || 'cellar';

  // S'assurer que wineId est toujours une chaîne valide
  const wineId = id || '';

  if (!wineId) {
    return null;
  }

  return <WineDetailsScreen wineId={wineId} isFromOcr={isFromOcr} tab={tab} />;
} 