// Images par défaut pour l'application
export const defaultAvatar = 'https://via.placeholder.com/84x84/F6A07A/FFFFFF?text=U';

// Images locales (si nécessaire)
// export const defaultAvatar = require('../assets/images/default-avatar.png');

// Images pour les vins
export const defaultWineImage = 'https://via.placeholder.com/300x200/F6A07A/FFFFFF?text=Vin';

// Images pour les domaines
export const defaultProducerImage = 'https://via.placeholder.com/200x200/F6A07A/FFFFFF?text=Domaine'; 